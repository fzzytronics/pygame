import time
import StoryBuilder
print("Welcome...")
time.sleep(1)
print("This is the terminal for the main game.")
print("Loading...")
time.sleep(4)
print("DONE!")

StoryBuilder.game()